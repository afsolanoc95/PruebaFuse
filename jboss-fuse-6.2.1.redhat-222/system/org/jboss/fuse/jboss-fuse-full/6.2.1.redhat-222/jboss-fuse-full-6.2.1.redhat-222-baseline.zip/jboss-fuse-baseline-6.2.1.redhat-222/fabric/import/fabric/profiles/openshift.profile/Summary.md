This is the OpenShift profile for running Fuse on OpenShift
