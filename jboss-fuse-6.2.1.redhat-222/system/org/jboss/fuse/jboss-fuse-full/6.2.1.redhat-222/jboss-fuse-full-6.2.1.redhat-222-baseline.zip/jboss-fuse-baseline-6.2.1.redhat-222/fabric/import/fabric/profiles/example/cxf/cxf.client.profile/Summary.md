This is the client profile for the client/server example Fabric and Apache CXF.
