the profile which runs a full JBoss A-MQ distribution and starts the broker on 61616 port
