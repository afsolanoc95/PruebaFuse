the base A-MQ broker profile
