This is the server profile for the client/server example where the client and server communications using HTTP. 
