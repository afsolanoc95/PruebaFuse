This is the client profile for the DOSGi client/server example.
