This is the bank3 profile for the loan broaker example
