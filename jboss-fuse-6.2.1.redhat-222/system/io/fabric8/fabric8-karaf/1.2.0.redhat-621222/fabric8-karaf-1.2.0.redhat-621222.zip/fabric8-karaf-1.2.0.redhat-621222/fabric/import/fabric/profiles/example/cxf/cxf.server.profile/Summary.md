This is the server profile for the client/server example Fabric and Apache CXF.
