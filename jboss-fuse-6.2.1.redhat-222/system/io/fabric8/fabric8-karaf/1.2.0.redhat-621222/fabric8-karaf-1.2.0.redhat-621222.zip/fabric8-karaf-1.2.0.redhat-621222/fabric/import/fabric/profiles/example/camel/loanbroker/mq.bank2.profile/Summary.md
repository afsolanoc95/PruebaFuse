This is the bank2 profile for the loan broaker example
